/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectoElectrodomesticopri;


import com.mycompany.proyectoelectrodomestico.gui.GUIPrincipal;

/**
 *
 * @author Catalina Troncoso
 */
public class ProyectoElectrodomestico {

    public static void main(String[] args) {
        GUIPrincipal gui = new GUIPrincipal();
        gui.setVisible(true);
        
    }
}
