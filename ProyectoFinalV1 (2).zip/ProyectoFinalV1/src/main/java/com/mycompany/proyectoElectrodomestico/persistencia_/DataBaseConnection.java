/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectoElectrodomestico.persistencia_;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author monto
 */
public class DataBaseConnection {
    
        /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author monto
 */
    private static final String URL      = "jdbc:mysql://localhost:3306/electrodomesticos";
    private static final String USUARIO  = "root";
    private static final String PASSWORD = "2008Mario";
    // ──────────────────────────────────────────────────────────────────────────
 
    private static Connection conexion = null;
 
  
    private DataBaseConnection() {}
 
 
    public static Connection getConexion() {
        try {
            if (conexion == null || conexion.isClosed()) {
                
                Class.forName("com.mysql.cj.jdbc.Driver");
 
                conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
                System.out.println("Conexión establecida correctamente.");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Driver no encontrado");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos.");
            e.printStackTrace();
        }
        return conexion;
    }
 
    
    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("Conexión cerrada.");
            }
        } catch (SQLException e) {
            System.out.println("rror al cerrar la conexión.");
            e.printStackTrace();
        }
    }

}
