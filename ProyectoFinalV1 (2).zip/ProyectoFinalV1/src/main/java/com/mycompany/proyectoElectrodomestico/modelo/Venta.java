package com.mycompany.proyectoElectrodomestico.modelo;


/**
 *
 * @author Per2026
 */

public class Venta {
    private int idVenta;
    private String fechaVenta;
    private String metodoPago;
    private double total;
    private String estado;

    public Venta(int idVenta, String fechaVenta, String metodoPago, double total, String estado) {
        this.idVenta = idVenta;
        this.fechaVenta = fechaVenta;
        this.metodoPago = metodoPago;
        this.total = total;
        this.estado = estado;
    }

    public int getIdVenta() { 
        return idVenta; 
    }
    
    public void setIdVenta(int idVenta) { 
       this.idVenta = idVenta; 
    }
    
    public String getFechaVenta() { 
        return fechaVenta; 
    }
    
    public void setFechaVenta(String fechaVenta) { 
        this.fechaVenta = fechaVenta; 
    }
    
    public String getMetodoPago() { 
        return metodoPago; 
    }
    
    public void setMetodoPago(String metodoPago) { 
        this.metodoPago = metodoPago; 
    }
    
    public double getTotal() { 
        return total; 
    }
    
    public void setTotal(double total) { 
        this.total = total; 
    }
    
    public String getEstado() { 
        return estado; 
    }
    
    public void setEstado(String estado) { 
        this.estado = estado; 
    }
}