package com.mycompany.proyectoElectrodomestico.servicio;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mycompany.proyectoElectrodomestico.modelo.Venta;
import com.mycompany.proyectoElectrodomestico.persistencia_.MongoConnection;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;

public class ServicioVenta {

    private static MongoCollection<Document> getColeccion() {
        MongoDatabase db = MongoConnection.getDatabase();
        return db.getCollection("venta");
    }

    public static boolean agregarVenta(Venta venta) {
        try {
            if (getColeccion().find(Filters.eq("id_venta", venta.getIdVenta())).first() != null) {
                System.out.println("Error: Ya existe una venta con ese ID.");
                return false;
            }
            Document doc = new Document("id_venta", venta.getIdVenta())
                    .append("fecha_venta", venta.getFechaVenta())
                    .append("metodo_pago", venta.getMetodoPago())
                    .append("total", venta.getTotal())
                    .append("estado", venta.getEstado());
            getColeccion().insertOne(doc);
            return true;
        } catch (Exception ex) {
            System.out.println("Error al agregar venta: " + ex);
            return false;
        }
    }

    public static Venta buscarVenta(int idVenta) {
        try {
            Document doc = getColeccion().find(Filters.eq("id_venta", idVenta)).first();
            if (doc != null) {
                return new Venta(
                        doc.getInteger("id_venta"),
                        doc.getString("fecha_venta"),
                        doc.getString("metodo_pago"),
                        doc.get("total", Number.class).doubleValue(),
                        doc.getString("estado")
                );
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar venta: " + ex);
        }
        return null;
    }

    public static List<Venta> listarVentas() {
        List<Venta> lista = new ArrayList<>();
        try {
            for (Document doc : getColeccion().find(Filters.eq("estado", "ACTIVO"))) {
                lista.add(new Venta(
                        doc.getInteger("id_venta"),
                        doc.getString("fecha_venta"),
                        doc.getString("metodo_pago"),
                        doc.get("total", Number.class).doubleValue(),
                        doc.getString("estado")
                ));
            }
        } catch (Exception ex) {
            System.out.println("Error al listar ventas: " + ex);
        }
        return lista;
    }

    public static boolean actualizarVenta(Venta venta) {
        try {
            getColeccion().updateOne(
                    Filters.eq("id_venta", venta.getIdVenta()),
                    Updates.combine(
                            Updates.set("metodo_pago", venta.getMetodoPago()),
                            Updates.set("total", venta.getTotal())
                    )
            );
            return true;
        } catch (Exception ex) {
            System.out.println("Error al actualizar venta: " + ex);
            return false;
        }
    }

    public static boolean eliminarVenta(int idVenta) {
        try {
            getColeccion().updateOne(
                    Filters.eq("id_venta", idVenta),
                    Updates.set("estado", "INACTIVO")
            );
            return true;
        } catch (Exception ex) {
            System.out.println("Error al eliminar venta: " + ex);
            return false;
        }
    }

    public static double sumatoriaTotal() {
        double suma = 0;
        try {
            for (Document doc : getColeccion().find(Filters.eq("estado", "ACTIVO"))) {
                suma += doc.get("total", Number.class).doubleValue();
            }
        } catch (Exception ex) {
            System.out.println("Error al calcular sumatoria: " + ex);
        }
        return suma;
    }

    public static Document buscarDocumentoVenta(int idVenta) {
        try {
            return getColeccion()
                    .find(Filters.eq("id_venta", idVenta))
                    .first();
        } catch (Exception ex) {
            System.out.println("Error al buscar documento venta: " + ex);
            return null;
        }
    }

    public static Document buscarDocumentoVentaPorObjectId(ObjectId id) {
        try {
            return getColeccion()
                    .find(Filters.eq("_id", id))
                    .first();
        } catch (Exception ex) {
            System.out.println("Error al buscar venta por ObjectId: " + ex);
            return null;
        }
    }
}
