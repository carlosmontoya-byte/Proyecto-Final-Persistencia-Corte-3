package com.mycompany.proyectoElectrodomestico.servicio;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mycompany.proyectoElectrodomestico.modelo.Producto;
import com.mycompany.proyectoElectrodomestico.persistencia_.MongoConnection;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;

public class ServicioProducto {

    private static MongoCollection<Document> getColeccion() {
        MongoDatabase db = MongoConnection.getDatabase();
        return db.getCollection("producto");
    }

    public static boolean agregarProducto(Producto producto) {
        try {
            // Validar PK única
            if (getColeccion().find(Filters.eq("id_producto", producto.getIdProducto())).first() != null) {
                System.out.println("Error: Ya existe un producto con ese ID.");
                return false;
            }
            Document doc = new Document("id_producto", producto.getIdProducto())
                    .append("nombre", producto.getNombre())
                    .append("descripcion", producto.getDescripcion())
                    .append("precio", producto.getPrecio())
                    .append("stock", producto.getStock())
                    .append("estado", producto.getEstado());
            getColeccion().insertOne(doc);
            return true;
        } catch (Exception ex) {
            System.out.println("Error al agregar producto: " + ex);
            return false;
        }
    }

    public static Producto buscarProducto(int idProducto) {
        try {
            Document doc = getColeccion().find(Filters.eq("id_producto", idProducto)).first();
            if (doc != null) {
                return new Producto(
                        doc.getInteger("id_producto"),
                        doc.getString("nombre"),
                        doc.getString("descripcion"),
                        doc.get("precio", Number.class).doubleValue(),
                        doc.getInteger("stock"),
                        doc.getString("estado")
                );
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar producto: " + ex);
        }
        return null;
    }

    public static List<Producto> listarProductos() {
        List<Producto> lista = new ArrayList<>();
        try {
            for (Document doc : getColeccion().find(Filters.eq("estado", "ACTIVO"))) {
                lista.add(new Producto(
                        doc.getInteger("id_producto"),
                        doc.getString("nombre"),
                        doc.getString("descripcion"),
                        doc.get("precio", Number.class).doubleValue(),
                        doc.getInteger("stock"),
                        doc.getString("estado")
                ));
            }
        } catch (Exception ex) {
            System.out.println("Error al listar productos: " + ex);
        }
        return lista;
    }

    public static boolean actualizarProducto(Producto producto) {
        try {
            getColeccion().updateOne(
                    Filters.eq("id_producto", producto.getIdProducto()),
                    Updates.combine(
                            Updates.set("nombre", producto.getNombre()),
                            Updates.set("precio", producto.getPrecio())
                    )
            );
            return true;
        } catch (Exception ex) {
            System.out.println("Error al actualizar producto: " + ex);
            return false;
        }
    }

    public static boolean eliminarProducto(int idProducto) {
        try {
            getColeccion().updateOne(
                    Filters.eq("id_producto", idProducto),
                    Updates.set("estado", "INACTIVO")
            );
            return true;
        } catch (Exception ex) {
            System.out.println("Error al eliminar producto: " + ex);
            return false;
        }
    }

    public static double sumatoriaPrecio() {
        double suma = 0;
        try {
            for (Document doc : getColeccion().find(Filters.eq("estado", "ACTIVO"))) {
                suma += doc.get("precio", Number.class).doubleValue();
            }
        } catch (Exception ex) {
            System.out.println("Error al calcular sumatoria: " + ex);
        }
        return suma;
    }

    public static Document buscarDocumentoProducto(int idProducto) {
        try {
            return getColeccion()
                    .find(Filters.eq("id_producto", idProducto))
                    .first();
        } catch (Exception ex) {
            System.out.println("Error al buscar documento producto: " + ex);
            return null;
        }
    }
    
    public static Document buscarDocumentoProductoPorObjectId(ObjectId id) {
    try {
        return getColeccion()
                .find(Filters.eq("_id", id))
                .first();
    } catch (Exception ex) {
        System.out.println("Error al buscar producto por ObjectId: " + ex);
        return null;
    }
}

}
