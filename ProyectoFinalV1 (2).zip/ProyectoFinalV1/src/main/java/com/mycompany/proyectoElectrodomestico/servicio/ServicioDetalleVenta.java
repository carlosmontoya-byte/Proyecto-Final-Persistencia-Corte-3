package com.mycompany.proyectoElectrodomestico.servicio;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mycompany.proyectoElectrodomestico.modelo.DetalleVenta;
import com.mycompany.proyectoElectrodomestico.persistencia_.MongoConnection;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import org.bson.types.ObjectId;

public class ServicioDetalleVenta {

    private static MongoCollection<Document> getColeccion() {
        MongoDatabase db = MongoConnection.getDatabase();
        return db.getCollection("detalle_venta");
    }

    public static boolean agregarDetalle(DetalleVenta detalle) {
        try {
            if (buscarDetalle(detalle.getIdDetalleVenta()) != null) {
                System.out.println("Error: Ya existe el detalle con ID " + detalle.getIdDetalleVenta());
                return false;
            }

            Document ventaDoc = ServicioVenta.buscarDocumentoVenta(detalle.getIdVenta());

            if (ventaDoc == null) {
                System.out.println("Error: No existe la venta con ID " + detalle.getIdVenta());
                return false;
            }

            Document productoDoc = ServicioProducto.buscarDocumentoProducto(detalle.getIdProducto());

            if (productoDoc == null) {
                System.out.println("Error: No existe el producto con ID " + detalle.getIdProducto());
                return false;
            }

            if (detalle.getCantidad() <= 0) {
                System.out.println("Error: La cantidad debe ser mayor que cero.");
                return false;
            }

            if (detalle.getPrecioUnitario() <= 0) {
                System.out.println("Error: El precio unitario debe ser mayor que cero.");
                return false;
            }

            double subtotal = detalle.getCantidad() * detalle.getPrecioUnitario();

            Document doc = new Document("id_detalle_venta", detalle.getIdDetalleVenta())
                    .append("id_venta", detalle.getIdVenta())
                    .append("venta_object_id", ventaDoc.getObjectId("_id"))
                    .append("id_producto", detalle.getIdProducto())
                    .append("producto_object_id", productoDoc.getObjectId("_id"))
                    .append("cantidad", detalle.getCantidad())
                    .append("precio_unitario", detalle.getPrecioUnitario())
                    .append("subtotal", subtotal)
                    .append("estado", "ACTIVO");

            getColeccion().insertOne(doc);

            return true;

        } catch (Exception ex) {
            System.out.println("Error al agregar detalle: " + ex);
            return false;
        }
    }

    public static DetalleVenta buscarDetalle(int idDetalle) {
        try {
            Document doc = getColeccion().find(Filters.eq("id_detalle_venta", idDetalle)).first();
            if (doc != null) {
                return new DetalleVenta(
                        doc.getInteger("id_detalle_venta"),
                        doc.getInteger("id_venta"),
                        doc.getInteger("id_producto"),
                        doc.getInteger("cantidad"),
                        doc.get("precio_unitario", Number.class).doubleValue(),
                        doc.get("subtotal", Number.class).doubleValue()
                );
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar detalle: " + ex);
        }
        return null;
    }

    public static List<DetalleVenta> listarDetallesConDatos() {
        List<DetalleVenta> lista = new ArrayList<>();

        try {
            for (Document detalleDoc : getColeccion().find(Filters.eq("estado", "ACTIVO"))) {

                ObjectId ventaObjectId = detalleDoc.getObjectId("venta_object_id");
                ObjectId productoObjectId = detalleDoc.getObjectId("producto_object_id");

                Document ventaDoc = ServicioVenta.buscarDocumentoVentaPorObjectId(ventaObjectId);
                Document productoDoc = ServicioProducto.buscarDocumentoProductoPorObjectId(productoObjectId);

                if (ventaDoc == null || productoDoc == null) {
                    continue;
                }

                int idDetalleVenta = detalleDoc.getInteger("id_detalle_venta");
                int idVenta = detalleDoc.getInteger("id_venta");
                int idProducto = detalleDoc.getInteger("id_producto");

                int cantidad = detalleDoc.getInteger("cantidad");
                double precioUnitario = detalleDoc.get("precio_unitario", Number.class).doubleValue();
                double subtotal = detalleDoc.get("subtotal", Number.class).doubleValue();

                String fechaVenta = ventaDoc.getString("fecha_venta");
                String metodoPago = ventaDoc.getString("metodo_pago");

                String nombreProducto = productoDoc.getString("nombre");
                String descripcionProducto = productoDoc.getString("descripcion");

                DetalleVenta item = new DetalleVenta(
                        idDetalleVenta,
                        idVenta,
                        fechaVenta,
                        metodoPago,
                        idProducto,
                        nombreProducto,
                        descripcionProducto,
                        cantidad,
                        precioUnitario,
                        subtotal
                );

                lista.add(item);
            }

        } catch (Exception ex) {
            System.out.println("Error al listar detalles con datos: " + ex);
        }

        return lista;
    }

    public static boolean actualizarDetalle(DetalleVenta detalle) {
        try {
            double subtotal = detalle.getCantidad() * detalle.getPrecioUnitario();
            getColeccion().updateOne(
                    Filters.eq("id_detalle_venta", detalle.getIdDetalleVenta()),
                    Updates.combine(
                            Updates.set("cantidad", detalle.getCantidad()),
                            Updates.set("precio_unitario", detalle.getPrecioUnitario()),
                            Updates.set("subtotal", subtotal)
                    )
            );
            return true;
        } catch (Exception ex) {
            System.out.println("Error al actualizar detalle: " + ex);
            return false;
        }
    }

    public static DetalleVenta buscarDetalleConDatos(int idDetalle) {
        try {
            Document detalleDoc = getColeccion()
                    .find(Filters.and(
                            Filters.eq("id_detalle_venta", idDetalle),
                            Filters.eq("estado", "ACTIVO")
                    ))
                    .first();

            if (detalleDoc == null) {
                return null;
            }

            ObjectId ventaObjectId = detalleDoc.getObjectId("venta_object_id");
            ObjectId productoObjectId = detalleDoc.getObjectId("producto_object_id");

            Document ventaDoc = ServicioVenta.buscarDocumentoVentaPorObjectId(ventaObjectId);
            Document productoDoc = ServicioProducto.buscarDocumentoProductoPorObjectId(productoObjectId);

            if (ventaDoc == null || productoDoc == null) {
                return null;
            }

            int idDetalleVenta = detalleDoc.getInteger("id_detalle_venta");
            int idVenta = detalleDoc.getInteger("id_venta");
            int idProducto = detalleDoc.getInteger("id_producto");

            int cantidad = detalleDoc.getInteger("cantidad");
            double precioUnitario = detalleDoc.get("precio_unitario", Number.class).doubleValue();
            double subtotal = detalleDoc.get("subtotal", Number.class).doubleValue();

            String fechaVenta = ventaDoc.getString("fecha_venta");
            String metodoPago = ventaDoc.getString("metodo_pago");

            String nombreProducto = productoDoc.getString("nombre");
            String descripcionProducto = productoDoc.getString("descripcion");

            return new DetalleVenta(
                    idDetalleVenta,
                    idVenta,
                    fechaVenta,
                    metodoPago,
                    idProducto,
                    nombreProducto,
                    descripcionProducto,
                    cantidad,
                    precioUnitario,
                    subtotal
            );

        } catch (Exception ex) {
            System.out.println("Error al buscar detalle con datos: " + ex);
            return null;
        }
    }

    public static boolean eliminarDetalle(int idDetalle) {
        try {
            getColeccion().updateOne(
                    Filters.eq("id_detalle_venta", idDetalle),
                    Updates.set("estado", "INACTIVO")
            );
            return true;
        } catch (Exception ex) {
            System.out.println("Error al eliminar detalle: " + ex);
            return false;
        }
    }
}
